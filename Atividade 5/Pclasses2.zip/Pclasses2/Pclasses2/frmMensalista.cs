﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses2
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtmatricula_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnInstancia1_Click(object sender, EventArgs e)
        {
            Mensalista objmensalista = new Mensalista();
            objmensalista.NomeEmpregado = txtnome.Text;
            objmensalista.Matricula = Convert.ToInt32(txtmatricula.Text);
            objmensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objmensalista.salarioMensal = Convert.ToDouble(txtSalario.Text);

            MessageBox.Show("Nome=" + objmensalista.NomeEmpregado + "\n" +
                            "Matricula=" + objmensalista.Matricula + "\n" +
                            "Tempo trabalho:" + objmensalista.TempoTrabalho() + "\n" +
                            "Salario final=" +
                            objmensalista.salarioBruto().ToString("N2"));

            MessageBox.Show(Mensalista.Empresa);
            MessageBox.Show(Mensalista.Filial);
        }

        private void txtData_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSalario_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnInstancia2_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista(
                Convert.ToInt32(txtmatricula.Text),
                txtnome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSalario.Text));

            MessageBox.Show("nome=" + ObjMensalista.NomeEmpregado + "\n" +
                           "matricula=" + ObjMensalista.Matricula + "\n" +
                           "tempo trabalho:" + ObjMensalista.TempoTrabalho() + "\n" +
                           "salario final=" +
                           ObjMensalista.salarioBruto().ToString("N2"));

        } 
    }
}
 